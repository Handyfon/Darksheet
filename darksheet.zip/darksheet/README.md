<b>SUPPORT: https://discord.gg/gs5hAgxBx3</b></br>
<b>My Modules: http://handyfon.net/foundry-modules/</b>

<b>INSTALL INSTRUCTIONS:
Use the manifest to install the module:<br/>
Manifest: https://raw.githubusercontent.com/Handyfon/Darksheet/master/module.json<br/>
and drag the rollable tables out of the compendium.<br/><b>

 https://github.com/Handyfon/Darksheet/blob/master/module.json<br/>
 
 Upcoming:
 -CSS May be Optional in the furture<br/>
 -Character sheet even more customizable<br/>
 -Automatic Calculation of Exhaustion based on dropdowns.<br/>
 
 Known Issues:
 -Items lose slots after any drag and drop
 
 Custom Character Sheet:
 

![Alt text](https://i.imgur.com/l09OQuN.png?raw=true "Custom Character Sheet")

<b>2.1 Update Featuring changes to the Inventory</b></br>
![Alt text](https://i.imgur.com/awl2yyU.png?raw=true "Custom Character Sheet")

Featuring:<br/>
Custom CSS<br/>
-Let players select their colour scheme for their own characters<br/>
-Training<br/>
-Spent trainings points<br/>
-Death Saves Checkboxes<br/>
-Fate Points<br/>
-Inspiration<br/>
-Hero Points (not part of darker dungeons)<br/>
-Track your Wounds<br/>


Custom Character Sheet:

![Alt text](https://i.imgur.com/I3AS1dg.png?raw=true "Custom Item Sheet and Inventory")

-Klick "Armor Class" to roll for wounds<br/>

![Alt text](https://i.imgur.com/o3ZgapV.png?raw=true "Custom Item Sheet and Inventory")

Easily roll for deathsaves or wounds.

![Alt text](https://i.imgur.com/6nPyHsZ.png?raw=true "Custom Item Sheet and Inventory")

![Alt text](https://i.imgur.com/tLtFjJP.png?raw=true "Custom Item Sheet and Inventory")

-Track Ammodice for every Item<br/>
-Track Notches and <b>automatic tracking of damage and quality of the weapons and armor</b>
-Track Item Slots.

![Alt text](https://i.imgur.com/7n26SLq.png?raw=true "Item Slots")

![Alt text](https://i.imgur.com/HB4CPIu.png?raw=true "Including Customizable Rollable Tables")

![Alt text](https://i.imgur.com/lHNTIej.png?raw=true "Track Resources")

-Keep track of your food and water<br/>
-Clickable Spell Burnoutdice with automatic consequence<br/>
-Buttons for: Critical Success, Critical Failure, Success at a Cost, Treat Wound and Heal Wound.<br/>
-Settings for Hitdice and Inventory Slots<br/>(Automatic calcultion of Inventory Slots)<br/>
-Automatic Exhaustion Calculation (WOP)<br/>
-Track Stress & Afflictions <br/>


This is only possible thanks to these really patient and helpful guys:
- @Madeira - @Sky - @Atropos 
- @Moo Man - @NickEast - @Red Reign
Special thanks to
- @DM Me Your Waifu and @Moerill for spending too much time pointing me in the right direction, I really cannot thank you enough!
