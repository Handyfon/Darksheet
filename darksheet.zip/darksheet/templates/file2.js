export default class test{
	generate_Day () {
		console.log("test");
	}
}